#wtrite a program to remove the item fro list with the help of remove method

my_list = [1,2,3]  # Create an empty list
my_list.remove(2)
print(my_list)
