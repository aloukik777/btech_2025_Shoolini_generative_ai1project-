# WAP to update a list with help of indexing


my_list = [1,2,3]  # Create an empty list
my_list.insert(my_list.index(3),23)
print(my_list)


