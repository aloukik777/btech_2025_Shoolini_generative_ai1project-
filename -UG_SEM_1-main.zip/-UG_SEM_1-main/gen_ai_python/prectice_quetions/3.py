# write a program to write a porgram to remove the item from list with pop method and print popup method

my_list = [1,2,3]  # Create an empty list
print(my_list.pop(1))
