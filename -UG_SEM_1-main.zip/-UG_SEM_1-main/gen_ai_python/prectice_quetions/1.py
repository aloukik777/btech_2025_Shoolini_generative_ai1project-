#Write program to create list and add item at the end of the list.

my_list = [1,2,3]  # Create an empty list
my_list.append(4)  # Add an item at the end of the list    
print(my_list)  