df=pd.read_csv("placement.csv")
