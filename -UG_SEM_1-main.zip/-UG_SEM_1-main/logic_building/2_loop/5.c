//printing patterns
//    *
//   **
//  ***

#include <stdio.h>

int main(void)
{

    int n = 4;
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n - i - 1; ++j)
        {
            printf(" ");
        }
        for (int k = 0; k < i + 1; ++k)
        {
            printf("*");
        }
        printf("\n");
    }
}