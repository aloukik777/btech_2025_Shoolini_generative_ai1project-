#include <stdio.h>



int main(void)
{

    int a,b;
    scanf("%d %d",&a,&b);
    a = a * a;
    printf("value of a2b : %d\n",a*b);
    b = b * b;
    printf("value of a2b : %d\n",a*b);
    b = b * b;
    printf("value of a2b : %d\n",a*b);

}